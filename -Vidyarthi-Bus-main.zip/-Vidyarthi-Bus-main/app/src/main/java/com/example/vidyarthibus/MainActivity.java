package com.example.vidyarthibus;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.transition.Fade;
import android.transition.TransitionManager;
import android.view.Gravity;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {
    private static final long FRESH_TIMEOUT_MS = 15 * 60 * 1000;
    private static final float REPORT_RADIUS_METERS = 1000f;

    private DatabaseReference dbRef;
    private DatabaseReference activeRouteRef;
    private ValueEventListener activeRouteListener;
    private Route currentRoute;
    private final List<Route> routes = new ArrayList<>();
    private boolean isFirebaseReady = false;

    private TextView crowdLabel;
    private TextView statusDetail;
    private TextView firebaseBadge;
    private ProgressBar crowdMeter;
    private LinearLayout autoContacts;
    private LinearLayout mainLayout;
    private PendingReport pendingReport;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupRoutes();
        initFirebase();
        buildUi();
        selectBus(0);
    }

    private void initFirebase() {
        try {
            String url = getString(R.string.firebase_database_url);
            if (url.contains("your-project-id")) {
                isFirebaseReady = false;
                return;
            }

            if (FirebaseApp.getApps(this).isEmpty()) {
                FirebaseOptions opt = new FirebaseOptions.Builder()
                        .setApplicationId(getString(R.string.firebase_app_id))
                        .setApiKey(getString(R.string.firebase_api_key))
                        .setProjectId(getString(R.string.firebase_project_id))
                        .setDatabaseUrl(url)
                        .build();
                FirebaseApp.initializeApp(this, opt);
            }
            dbRef = FirebaseDatabase.getInstance().getReference("bus_reports");
            isFirebaseReady = true;
        } catch (Exception e) {
            isFirebaseReady = false;
        }
    }

    private void buildUi() {
        getWindow().setStatusBarColor(getColor(R.color.status_bar));
        getWindow().setNavigationBarColor(getColor(R.color.screen_bg));

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(getColor(R.color.screen_bg));
        scroll.setFillViewport(true);

        mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setPadding(dp(18), dp(18), dp(18), dp(34));
        scroll.addView(mainLayout);

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(22), dp(22), dp(22), dp(20));
        hero.setBackground(gradient(new int[]{getColor(R.color.hero_start), getColor(R.color.hero_mid), getColor(R.color.hero_end)}, dp(28)));
        hero.setElevation(dp(10));
        mainLayout.addView(hero, spacedLp(-1, -2, 0, 0, 0, dp(18)));

        LinearLayout topLine = new LinearLayout(this);
        topLine.setGravity(Gravity.CENTER_VERTICAL);
        hero.addView(topLine, new LinearLayout.LayoutParams(-1, -2));

        topLine.addView(pill("SMART STUDENT TRANSIT", getColor(R.color.pill_bg), Color.WHITE));

        firebaseBadge = pill(isFirebaseReady ? "LIVE SYNC" : "DEMO MODE",
                isFirebaseReady ? getColor(R.color.success) : getColor(R.color.danger), Color.WHITE);
        LinearLayout.LayoutParams badgeLp = new LinearLayout.LayoutParams(-2, -2);
        badgeLp.gravity = Gravity.RIGHT;
        badgeLp.leftMargin = dp(8);
        badgeLp.weight = 1f;
        topLine.addView(firebaseBadge, badgeLp);

        TextView title = new TextView(this);
        title.setText("Vidyarthi Bus");
        title.setTextSize(38);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(Color.WHITE);
        title.setPadding(0, dp(18), 0, dp(4));
        hero.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Crowd status, route confidence, and quick backup rides in one fast screen.");
        sub.setTextColor(getColor(R.color.hero_text_soft));
        sub.setTextSize(15);
        sub.setLineSpacing(dp(2), 1f);
        hero.addView(sub);

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.setPadding(0, dp(18), 0, 0);
        hero.addView(stats);
        stats.addView(heroStat("15 min", "fresh reports"), statLp(0, dp(6)));
        stats.addView(heroStat("1 km", "trusted range"), statLp(dp(6), dp(6)));
        stats.addView(heroStat("Auto", "backup ready"), statLp(dp(6), 0));

        LinearLayout routePanel = panel();
        routePanel.addView(headerLabel("SELECT ROUTE"));
        Spinner spinner = new Spinner(this);
        List<String> names = new ArrayList<>();
        for (Route r : routes) {
            names.add(r.name);
        }
        spinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));
        spinner.setPadding(dp(14), dp(10), dp(14), dp(10));
        spinner.setBackground(roundStroke(getColor(R.color.surface_alt), dp(16), getColor(R.color.outline), dp(1)));
        routePanel.addView(spinner, spacedLp(-1, dp(54), 0, dp(8), 0, 0));
        mainLayout.addView(routePanel, spacedLp(-1, -2, 0, 0, 0, dp(16)));

        LinearLayout meterCard = new LinearLayout(this);
        meterCard.setOrientation(LinearLayout.VERTICAL);
        meterCard.setPadding(dp(20), dp(20), dp(20), dp(22));
        meterCard.setBackground(gradient(new int[]{getColor(R.color.meter_start), getColor(R.color.meter_end)}, dp(26)));
        meterCard.setElevation(dp(8));
        meterCard.addView(headerLabelOnDark("LIVE CROWD METER"));

        crowdLabel = new TextView(this);
        crowdLabel.setText("No Current Data");
        crowdLabel.setTextSize(30);
        crowdLabel.setTypeface(null, Typeface.BOLD);
        crowdLabel.setTextColor(Color.WHITE);
        meterCard.addView(crowdLabel);

        statusDetail = new TextView(this);
        statusDetail.setText("Reports auto-expire after 15 minutes.");
        statusDetail.setTextColor(getColor(R.color.hero_text_soft));
        statusDetail.setTextSize(14);
        statusDetail.setPadding(0, dp(4), 0, dp(18));
        meterCard.addView(statusDetail);

        crowdMeter = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        crowdMeter.setMax(100);
        crowdMeter.setProgress(15);
        crowdMeter.setProgressDrawable(meterDrawable(getColor(R.color.success)));
        meterCard.addView(crowdMeter, new LinearLayout.LayoutParams(-1, dp(28)));
        mainLayout.addView(meterCard, spacedLp(-1, -2, 0, 0, 0, dp(16)));

        LinearLayout reportPanel = panel();
        reportPanel.addView(headerLabel("REPORT NOW"));
        TextView reportHint = new TextView(this);
        reportHint.setText("Your report is accepted only near the route, so the crowd meter stays trustworthy.");
        reportHint.setTextSize(13);
        reportHint.setTextColor(getColor(R.color.text_secondary));
        reportPanel.addView(reportHint, spacedLp(-1, -2, 0, 0, 0, dp(14)));

        Button fullBtn = createBigBtn("Bus is full", getColor(R.color.danger), getColor(R.color.danger_dark));
        fullBtn.setOnClickListener(v -> handleReport(100, "Bus is FULL"));
        reportPanel.addView(fullBtn, spacedLp(-1, dp(58), 0, 0, 0, dp(10)));

        Button cancelBtn = createSmallBtn("Bus cancelled", getColor(R.color.danger), getColor(R.color.danger_soft));
        cancelBtn.setOnClickListener(v -> handleReport(100, "Bus CANCELLED"));
        reportPanel.addView(cancelBtn, spacedLp(-1, dp(54), 0, 0, 0, dp(10)));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button emptyBtn = createSmallBtn("Seats free", getColor(R.color.success), getColor(R.color.success_soft));
        emptyBtn.setOnClickListener(v -> handleReport(20, "Plenty of Seats"));
        Button seatsBtn = createSmallBtn("Few seats", getColor(R.color.warning), getColor(R.color.warning_soft));
        seatsBtn.setOnClickListener(v -> handleReport(60, "Some Seats Left"));
        row.addView(emptyBtn, buttonLp(0, dp(6)));
        row.addView(seatsBtn, buttonLp(dp(6), 0));
        reportPanel.addView(row);
        mainLayout.addView(reportPanel, spacedLp(-1, -2, 0, 0, 0, dp(16)));

        LinearLayout autoPanel = panel();
        autoPanel.addView(headerLabel("SHARED AUTO BACKUP"));
        autoContacts = new LinearLayout(this);
        autoContacts.setOrientation(LinearLayout.VERTICAL);
        autoPanel.addView(autoContacts);
        mainLayout.addView(autoPanel);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> p, android.view.View v, int pos, long id) {
                selectBus(pos);
            }

            @Override
            public void onNothingSelected(AdapterView<?> p) {
            }
        });

        setContentView(scroll);
    }

    private void handleReport(int level, String status) {
        LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            pendingReport = new PendingReport(level, status);
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }

        boolean gpsOn = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        boolean networkOn = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        if (!gpsOn && !networkOn) {
            Toast.makeText(this, "Turn on device location to report bus status.", Toast.LENGTH_LONG).show();
            return;
        }

        Location lastLocation = freshestLocation(lm.getLastKnownLocation(LocationManager.GPS_PROVIDER),
                lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER));
        if (lastLocation != null && System.currentTimeMillis() - lastLocation.getTime() < 2 * 60 * 1000) {
            checkLocationAndSubmit(lastLocation, level, status);
            return;
        }

        Toast.makeText(this, "Checking if you are near this route...", Toast.LENGTH_SHORT).show();
        Handler timeout = new Handler(Looper.getMainLooper());
        final boolean[] finished = {false};
        LocationListener listener = new LocationListener() {
            @Override
            public void onLocationChanged(Location loc) {
                if (finished[0]) {
                    return;
                }
                finished[0] = true;
                lm.removeUpdates(this);
                checkLocationAndSubmit(loc, level, status);
            }

            @Override
            public void onStatusChanged(String p, int s, Bundle e) {
            }

            @Override
            public void onProviderEnabled(String p) {
            }

            @Override
            public void onProviderDisabled(String p) {
            }
        };

        if (gpsOn) {
            lm.requestSingleUpdate(LocationManager.GPS_PROVIDER, listener, Looper.getMainLooper());
        }
        if (networkOn) {
            lm.requestSingleUpdate(LocationManager.NETWORK_PROVIDER, listener, Looper.getMainLooper());
        }
        timeout.postDelayed(() -> {
            if (!finished[0]) {
                finished[0] = true;
                lm.removeUpdates(listener);
                Toast.makeText(this, "Location not found yet. Open Maps once, then try again.", Toast.LENGTH_LONG).show();
            }
        }, 10000);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && pendingReport != null) {
            PendingReport report = pendingReport;
            pendingReport = null;
            handleReport(report.level, report.status);
        } else if (requestCode == 1) {
            Toast.makeText(this, "Location permission is required to report.", Toast.LENGTH_LONG).show();
        }
    }

    private Location freshestLocation(Location gps, Location network) {
        if (gps == null) {
            return network;
        }
        if (network == null) {
            return gps;
        }
        return gps.getTime() >= network.getTime() ? gps : network;
    }

    private void checkLocationAndSubmit(Location loc, int level, String status) {
        float nearest = currentRoute.nearestStopDistance(loc);
        String debug = String.format(java.util.Locale.US, "You: %.4f, %.4f | nearest route stop: %.0f m",
                loc.getLatitude(), loc.getLongitude(), nearest);
        if (nearest >= REPORT_RADIUS_METERS) {
            Toast.makeText(this, "Blocked: not near this route. " + debug, Toast.LENGTH_LONG).show();
            return;
        }

        if (!isFirebaseReady) {
            updateMeterUi(level, status, "DEMO");
            Toast.makeText(this, "Allowed. " + debug, Toast.LENGTH_LONG).show();
            return;
        }

        Map<String, Object> map = new HashMap<>();
        map.put("level", level);
        map.put("status", status);
        map.put("timestamp", ServerValue.TIMESTAMP);
        dbRef.child(currentRoute.id).push().setValue(map, (error, ref) -> {
            if (error != null) {
                Toast.makeText(this, "Firebase failed: " + error.getMessage(), Toast.LENGTH_LONG).show();
                return;
            }
            updateMeterUi(level, status, "LIVE");
            Toast.makeText(this, "Report sent. " + debug, Toast.LENGTH_LONG).show();
        });
    }

    private void selectBus(int pos) {
        currentRoute = routes.get(pos);
        updateAutos();
        attachFirebaseListener();
    }

    private void attachFirebaseListener() {
        if (!isFirebaseReady) {
            return;
        }

        if (activeRouteRef != null && activeRouteListener != null) {
            activeRouteRef.removeEventListener(activeRouteListener);
        }

        activeRouteRef = dbRef.child(currentRoute.id);
        activeRouteListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                long now = System.currentTimeMillis();
                DataSnapshot latest = null;
                for (DataSnapshot child : snapshot.getChildren()) {
                    Long ts = child.child("timestamp").getValue(Long.class);
                    if (ts != null && (now - ts) < FRESH_TIMEOUT_MS) {
                        latest = child;
                    } else {
                        child.getRef().removeValue();
                    }
                }
                if (latest != null) {
                    updateMeterUi(readLevel(latest.child("level")),
                            latest.child("status").getValue(String.class), "LIVE");
                } else {
                    updateMeterUi(0, "Waiting for report", "");
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        };
        activeRouteRef.addValueEventListener(activeRouteListener);
    }

    private Integer readLevel(DataSnapshot snapshot) {
        Object value = snapshot.getValue();
        if (value instanceof Long) {
            return ((Long) value).intValue();
        }
        if (value instanceof Integer) {
            return (Integer) value;
        }
        if (value instanceof Double) {
            return ((Double) value).intValue();
        }
        if (value instanceof String) {
            try {
                return Integer.parseInt((String) value);
            } catch (NumberFormatException ignored) {
                return null;
            }
        }
        return null;
    }

    private void updateMeterUi(Integer levelValue, String status, String source) {
        int level = levelValue == null ? 0 : levelValue;
        TransitionManager.beginDelayedTransition(mainLayout, new Fade());
        crowdLabel.setText(status == null ? "Waiting for report" : status);
        statusDetail.setText(source == null || source.isEmpty() ? "Waiting for report..." : source + " UPDATE | Sub-second sync");

        int color = level > 80 ? getColor(R.color.danger) : (level > 40 ? getColor(R.color.warning) : getColor(R.color.success));
        crowdMeter.setProgressDrawable(meterDrawable(color));

        ObjectAnimator anim = ObjectAnimator.ofInt(crowdMeter, "progress", crowdMeter.getProgress(), level);
        anim.setDuration(700);
        anim.setInterpolator(new android.view.animation.DecelerateInterpolator());
        anim.start();
    }

    private void setupRoutes() {
        Route r1 = new Route("RJN-YLK", "Rajanukunte to Yelahanka");
        r1.stops.add(new Stop("Rajanukunte", 13.1738, 77.5648));
        r1.stops.add(new Stop("Avalahalli", 13.1477, 77.5688));
        r1.stops.add(new Stop("Yelahanka", 13.1007, 77.5963));
        r1.autos.add(new AutoContact("Rajanukunte Auto Stand", "9848011223"));
        routes.add(r1);

        Route r2 = new Route("YLK-BLR", "Yelahanka to Bengaluru");
        r2.stops.add(new Stop("Yelahanka", 13.1007, 77.5963));
        r2.stops.add(new Stop("Hebbal", 13.0358, 77.5970));
        r2.stops.add(new Stop("Bengaluru Majestic", 12.9767, 77.5713));
        r2.autos.add(new AutoContact("Yelahanka Shared Auto", "9000112233"));
        routes.add(r2);

        Route r3 = new Route("RJN-BLR", "Rajanukunte to Bengaluru");
        r3.stops.add(new Stop("Rajanukunte", 13.1738, 77.5648));
        r3.stops.add(new Stop("Yelahanka", 13.1007, 77.5963));
        r3.stops.add(new Stop("Hebbal", 13.0358, 77.5970));
        r3.stops.add(new Stop("Bengaluru Majestic", 12.9767, 77.5713));
        r3.autos.add(new AutoContact("Rajanukunte Auto Stand", "9848011223"));
        r3.autos.add(new AutoContact("Yelahanka Shared Auto", "9000112233"));
        routes.add(r3);
    }

    private void updateAutos() {
        autoContacts.removeAllViews();
        for (AutoContact a : currentRoute.autos) {
            Button b = new Button(this);
            b.setText("Call " + a.name + "  |  " + a.phone);
            b.setAllCaps(false);
            b.setTextSize(14);
            b.setTypeface(null, Typeface.BOLD);
            b.setTextColor(getColor(R.color.accent_dark));
            b.setBackground(roundStroke(getColor(R.color.accent_soft), dp(16), getColor(R.color.accent), dp(1)));
            b.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + a.phone))));
            autoContacts.addView(b, spacedLp(-1, dp(54), 0, dp(8), 0, 0));
        }
    }

    private TextView headerLabel(String txt) {
        TextView t = new TextView(this);
        t.setText(txt);
        t.setTextSize(11);
        t.setTypeface(null, Typeface.BOLD);
        t.setTextColor(getColor(R.color.text_secondary));
        t.setPadding(0, 0, 0, dp(10));
        return t;
    }

    private TextView headerLabelOnDark(String txt) {
        TextView t = headerLabel(txt);
        t.setTextColor(getColor(R.color.hero_text_soft));
        return t;
    }

    private Button createBigBtn(String txt, int start, int end) {
        Button b = new Button(this);
        b.setText(txt);
        b.setTextColor(getColor(R.color.button_text));
        b.setAllCaps(false);
        b.setTextSize(17);
        b.setTypeface(null, Typeface.BOLD);
        b.setBackground(gradient(new int[]{start, end}, dp(18)));
        b.setElevation(dp(4));
        return b;
    }

    private Button createSmallBtn(String txt, int text, int bg) {
        Button b = new Button(this);
        b.setText(txt);
        b.setTextColor(text);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTypeface(null, Typeface.BOLD);
        b.setBackground(roundStroke(bg, dp(16), text, dp(1)));
        return b;
    }

    private GradientDrawable roundCard(int col, int rad) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(col);
        d.setCornerRadius(rad);
        return d;
    }

    private GradientDrawable roundStroke(int col, int rad, int stroke, int width) {
        GradientDrawable d = roundCard(col, rad);
        d.setStroke(width, stroke);
        return d;
    }

    private GradientDrawable gradient(int[] colors, int rad) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        d.setCornerRadius(rad);
        return d;
    }

    private LinearLayout panel() {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(18), dp(18), dp(18), dp(18));
        p.setBackground(roundStroke(getColor(R.color.surface), dp(22), getColor(R.color.outline), dp(1)));
        p.setElevation(dp(3));
        return p;
    }

    private TextView pill(String text, int bg, int fg) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(11);
        t.setTypeface(null, Typeface.BOLD);
        t.setTextColor(fg);
        t.setPadding(dp(10), dp(6), dp(10), dp(6));
        t.setBackground(roundCard(bg, dp(18)));
        return t;
    }

    private LinearLayout heroStat(String value, String label) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(10), dp(10), dp(10));
        box.setBackground(roundStroke(getColor(R.color.hero_glass), dp(18), getColor(R.color.hero_glass_stroke), dp(1)));

        TextView v = new TextView(this);
        v.setText(value);
        v.setTextColor(Color.WHITE);
        v.setTextSize(18);
        v.setTypeface(null, Typeface.BOLD);

        TextView l = new TextView(this);
        l.setText(label);
        l.setTextColor(getColor(R.color.hero_text_soft));
        l.setTextSize(11);

        box.addView(v);
        box.addView(l);
        return box;
    }

    private Drawable meterDrawable(int color) {
        GradientDrawable bg = roundCard(getColor(R.color.meter_track), dp(20));
        GradientDrawable fill = gradient(new int[]{color, getColor(R.color.meter_fill_hot)}, dp(20));
        ClipDrawable clipped = new ClipDrawable(fill, Gravity.LEFT, ClipDrawable.HORIZONTAL);
        LayerDrawable layers = new LayerDrawable(new Drawable[]{bg, clipped});
        layers.setId(0, android.R.id.background);
        layers.setId(1, android.R.id.progress);
        return layers;
    }

    private LinearLayout.LayoutParams spacedLp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, h);
        lp.setMargins(l, t, r, b);
        return lp;
    }

    private LinearLayout.LayoutParams statLp(int left, int right) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.leftMargin = left;
        lp.rightMargin = right;
        return lp;
    }

    private LinearLayout.LayoutParams buttonLp(int left, int right) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(54), 1f);
        lp.leftMargin = left;
        lp.rightMargin = right;
        return lp;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    static class Route {
        String id;
        String name;
        List<Stop> stops = new ArrayList<>();
        List<AutoContact> autos = new ArrayList<>();

        Route(String i, String n) {
            id = i;
            name = n;
        }

        float nearestStopDistance(Location loc) {
            float nearest = Float.MAX_VALUE;
            for (Stop stop : stops) {
                float[] res = new float[1];
                Location.distanceBetween(loc.getLatitude(), loc.getLongitude(), stop.lat, stop.lon, res);
                nearest = Math.min(nearest, res[0]);
            }
            return nearest;
        }
    }

    static class Stop {
        String name;
        double lat;
        double lon;

        Stop(String n, double la, double lo) {
            name = n;
            lat = la;
            lon = lo;
        }
    }

    static class AutoContact {
        String name;
        String phone;

        AutoContact(String n, String p) {
            name = n;
            phone = p;
        }
    }

    static class PendingReport {
        int level;
        String status;

        PendingReport(int l, String s) {
            level = l;
            status = s;
        }
    }
}
